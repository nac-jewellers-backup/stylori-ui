import React from 'react';
import './screens.css'

export const Loading = (
    <div className="overall-loader">
        <div id="loading"></div>
    </div>
)

export default Loading;