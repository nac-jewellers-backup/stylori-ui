export const LogRegData = [
    {
        title: "New to Stylori?",
        dis: 'Register now',
        button:"Register",
        buttonval:"Register",
    },
    {
        title: "Already Registered? ",
        dis: 'Login now',
        buttonval:"Login",
        button:"Login",
    },
    {
        title: "Skip Password and continue as Guest ",
        dis: '(You will need to be logged in to use Promo code)',
        button:"Continue",
        buttonval:"Continue as a Guest ",
    },
]
