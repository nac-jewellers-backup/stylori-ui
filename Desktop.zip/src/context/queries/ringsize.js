
export const RINGSIZE = `{
    allMasterRingsSizes {
      nodes {
        size
        name
      }
    }
  }`