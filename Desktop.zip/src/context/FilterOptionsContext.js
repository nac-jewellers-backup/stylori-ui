import React, { useEffect } from 'react';
import { useGraphql } from 'hooks/GraphqlHook';
import { PRODUCTLIST, conditions } from 'queries/productListing';
import { withRouter } from 'react-router-dom';
// import { productsPendants } from 'mappers/dummydata';
// import { object } from 'prop-types';

// let setFilter;
const initialCtx = {
    FilterOptionsCtx: {
        filters: {
            Offers: null, Availability: null, ProductType: null, style: null, material: null, Theme: null, Collection: null, metalColor: null,
            MetalPurity: null, Occasion: null, NoOfStones: null, Gender: null, stoneColor: null, stoneShape: null
        },
        loading: false, error: false, data: [], offset:3,dataArr:[],first:2
    },
    setFilters: (filterData) => { }
}

export const FilterOptionsContext = React.createContext(initialCtx);
export const FilterOptionsConsumer = FilterOptionsContext.Consumer;

const Provider = (props) => {
    const [filters, setFilters] = React.useState({
        Offers: {}, Availability: {}, ProductType: {}, style: {}, material: {}, Theme: {}, Collection: {}, metalColor: {},
        MetalPurity: {}, Occasion: {}, NoOfStones: {}, Gender: {}, stoneColor: {}, stoneShape: {}
    });
const [offset, setOffset] = React.useState(0)
const [first, setFirst] = React.useState(0)

const [dataArr, setDataArr] = React.useState([])

    var offers = [];
    var queries = []
    const pathQueries = () => {
        // var queries = []
        Object.keys(filters).map(fk => {
            const filter = filters[fk];
            const fv = Object.keys(filter);
            if (fv.length > 0) {
                // console.info('filter[fk[0]]', filter[fv[0]], filter, fv)
                if (filter[fv[0]]) {
                    const qt = `${fk}=${fv[0]}`;
                    queries.push(qt);
                }

            }
        })
        // console.info('queries', queries);
        const query = encodeURI(queries.join("&"));
        // console.info('QUERYIES', query);
        props.history.push({
            pathname: '/stylori',
            search: query !== '' ? query : window.location.search,
        })
    }


   

    // console.log('queries', props.location.search)

    // Destructuring the query parameters from the URL
    let paramsArrayOfObject = [];
    if (window.location.search) {

        let urlSearchparamsDecode = decodeURI(window.location.search);
        let urlParams = urlSearchparamsDecode.replace('?', '').split('&');
        let urlSplitparamsEqual = urlParams.map(val => {
            let splitval = val.split('=');
            return { [splitval[0]]: splitval[1] }
        })
        paramsArrayOfObject = urlSplitparamsEqual;
        console.log('val',paramsArrayOfObject)

    }

        const offsetvariable = {}
        offsetvariable['offsetvar']=initialCtx.FilterOptionsCtx.offset;
        const firstvariable ={}
        firstvariable['firstvar'] = initialCtx.FilterOptionsCtx.first;
    // const variables =  {};
    const conditionFilters =conditions.generateFilters(paramsArrayOfObject)
    const variables =  { ...conditionFilters, 'offsetvar':initialCtx.FilterOptionsCtx.offset, 'firstvar':initialCtx.FilterOptionsCtx.first}

    // console.log('variables', variables);
    var { loading, error, data, makeRequest } = useGraphql(PRODUCTLIST, () => { }, variables);
    
    var a = [];
    // var b = a.concat(data)
    // dataArr.push(b)
    


    useEffect(() => {
        // console.info('FILTERSS', window.location.search);
        
        setDataArr(a.concat(data))
        // makeRequest(variables)    
        pathQueries()
        
    },[data])

    
    const FilterOptionsCtx = {
        filters, loading, error, data, setFilters, offset, setOffset,dataArr, first, setFirst 
    }


    return (
        <FilterOptionsContext.Provider value={{ FilterOptionsCtx, setFilters, setOffset, setFirst }} >
            {props.children}
        </FilterOptionsContext.Provider>
    )
};

export const FilterOptionsProvider = withRouter(Provider);