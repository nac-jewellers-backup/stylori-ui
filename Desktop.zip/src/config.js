export const API_URL = "http://auth-dev.ap-south-1.elasticbeanstalk.com"
export const HOME_PAGE_URL = ""
export const CDN_URL = "https://s3.ap-south-1.amazonaws.com/staging-assets.stylori.com/base_images/"