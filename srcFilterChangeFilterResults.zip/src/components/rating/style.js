const styles = theme => ({
    backgsecondary: {
        background: theme.palette.secondary.main,
    },
});
export default styles;