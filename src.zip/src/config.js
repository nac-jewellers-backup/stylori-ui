export const API_URL = "http://auth-dev.ap-south-1.elasticbeanstalk.com"
export const HOME_PAGE_URL = ""
export const CDN_URL = "https://assets-cdn.stylori.com/"