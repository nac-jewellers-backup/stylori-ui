export const resolutions = [
  { res: '318x318', size: '375w' },
  { res: '372x372', size: '500w' },
  { res: '276x276', size: '1440w' },
  { res: '422x422', size: '600w' },
  { res: '247x247', size: '768w' },
  { res: '204x204', size: '1024w' },
  { res: '543x543', size: '2560w' },
]

export const filterGenerator = (type, value, table, clause = "equalTo") => {
  return {
    [table]: {
      some: {
        [type]: {
          [clause]: value
        }
      }
    }
  }
}