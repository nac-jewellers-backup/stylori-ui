export * from './filterdata';
export * from './headerdata';
export * from './descriptiondata';
export * from './productcarddata';
export * from './cartdata'
export * from './productpricingPage'
export * from './checkoutloginReg'