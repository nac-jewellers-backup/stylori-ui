import React from "react";
import CheckBox from "./CheckBox";

export default function Checkbox(props) {
  return (
      <CheckBox CheckBoxValues={props.CheckBoxValues} />

  );
}