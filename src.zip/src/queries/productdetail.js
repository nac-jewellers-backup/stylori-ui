import { filterGenerator } from "utils";
export const PRODUCTDETAILS = `query fetchProductDetails($condition: ProductListCondition) {
  allProductLists(condition: $condition, first: 10) {
    nodes {
      productName
      productId
      defaultSize
      sizeVarient
      colourVarient
      defaultWeight
      productType
      productImagesByProductId {
        nodes {
          ishover
          imageUrl
          imagePosition
        }
      }
      productDiamondsByProductSku {
        nodes {
          diamondClarity
          diamondColour
          diamondType
          stoneWeight
          diamondShape
          diamondSettings
          stoneCount
        }
      }
      transSkuListsByProductId(condition: {isdefault: true}) {
        nodes {
          skuSize
          markupPrice
          sellingPrice
          purity
          metalColor
            transSkuDescriptionsBySkuId {
            nodes {
              skuDescription
            }
          }
        }
      }
      productGemstonesByProductSku {
        nodes {
          gemstoneType
          gemstoneSize
          gemstoneShape
          gemstoneSetting
          productSku
          stoneCount
        }
      }
    }
  }
}
`
export const filterProductMatrix = (type, value) => {
  let fc = { table: "", type: "" }
  switch (type) {
    case "productId": {
      fc = {
        table: "allProductLists",
        type: "productId"
      }
      break;
    }
    case "diamondClarity": {
      fc = {
        table: "productDiamondsByProductSku",
        type: "diamondClarity"
      }
      break;
    }

    default: {
      break;
    }
  }

  return filterGenerator(fc.type, value, fc.table);
}

export const conditions = {
  productId: (id) => ({
    "condition": {
      "productId": id
    }
  }),


  generateFilters: (filters) => {
    debugger
    let filter = {};
    const filterKeys = filters.map(val => val);

    filterKeys.map(k => {
      debugger
      const fk = String(Object.keys(k));
      const fval = String(Object.values(k));
      const fquery = filterProductMatrix(fk, fval);
      filter = { ...filter, ...fquery };
    })

    debugger
    if (Object.keys(filter).length > 0) {
      return { filter };
    } else {
      return {};
    }
  }
}