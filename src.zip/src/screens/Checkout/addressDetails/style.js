const styles = theme => ({
   
    normalfonts: {
        color: theme.palette.text.primary,
    },
});
export default styles;