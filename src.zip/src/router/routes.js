
export const routes = {
    stylori: '/stylori',
    PricingPage:'/pricingPage',
    Cart:'/cart',
    Checkout:'/Checkout',
    Register:'/register'

}

export default routes;
