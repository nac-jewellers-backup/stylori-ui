export const API_URL = "https://api.stylori.net"
export const HOME_PAGE_URL = ""
export const CDN_URL = "https://assets.stylori.net/base_images/"