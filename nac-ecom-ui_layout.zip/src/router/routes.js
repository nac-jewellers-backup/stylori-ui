export const routes = {
    stylori: '/stylori',

}

export default routes;
