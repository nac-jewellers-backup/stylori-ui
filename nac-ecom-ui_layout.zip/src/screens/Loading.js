import React from 'react';

export const Loading = (
    <div>
        Loading Page
    </div>
)

export default Loading;