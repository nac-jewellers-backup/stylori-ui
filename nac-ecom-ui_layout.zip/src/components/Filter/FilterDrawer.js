import React,{Component} from 'react';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import { filter, filter1 } from './Filterdata';
import ListItemText from '@material-ui/core/ListItemText';
import Typography from '@material-ui/core/Typography';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';

const styles = theme => ({
    root: {
      display: 'flex',
  
    },
    appBar: {
      transition: theme.transitions.create(['margin', 'width'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      
      }),
    },
    appBarShift: {
      width: `calc(100% - ${drawerWidth}px)`,
      marginLeft: drawerWidth,
      transition: theme.transitions.create(['margin', 'width'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    menuButton: {
      marginLeft: 12,
      marginRight: 20,
    },
    hide: {
      display: 'none',
    },
    drawer: {
      width: drawerWidth,
      flexShrink: 0,
      position:'sticky',
      zIndex:'9999'
  
    },
    drawerPaper: {
      width: drawerWidth,
  top:'165px',
    },
    drawerHeader: {
      display: 'flex',
      alignItems: 'center',
      padding: '0 8px',
      ...theme.mixins.toolbar,
      justifyContent: 'flex-end',
      
    },
    content: {
      flexGrow: 1,
      padding: theme.spacing.unit * 3,
      transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      marginLeft: -drawerWidth,
    },
    contentShift: {
      transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: 0,
    },
  });

class FilterHeader extends Component{
    constructor(props){
        super(props)
    }
    render(){
        
      
        return(

<div>
        <Drawer
          className={classes.drawer}
          // style={{position:'sticky'}}
          variant="persistent"
          anchor="left"
          open={open}
          classes={{
            paper: classes.drawerPaper,
          }}
        >
          {/* <div className={classes.drawerHeader}>
            <IconButton onClick={this.handleDrawerClose}>
              {theme.direction === 'ltr' ? <ChevronLeftIcon /> : <ChevronRightIcon />}
            </IconButton>
          </div> */}
                     <div style={{ width: "240px"}}>
              <IconButton onClick={this.handleDrawerClose}
                style={{ float: 'right' }}>
                <i style={{ color: "#394578", margin: "45%" }} class="fa fa-times"></i>
              </IconButton >
              <IconButton onClick={this.handleDrawerClose}>
                <ChevronRightIcon className="arrow" />
                <Typography color="inherit"
                  onClick={this.handleDrawerClose} noWrap
                  className="fil-drawer-head"
                >
                  Filter By
            </Typography>
              </IconButton>
            </div>
          <Divider />
          <List className="fil-main-list">
              <div style={{ margin: "5px" }}>
                <Typography className="fil-list-items">Price</Typography>
                <Grid container spacing={12} style={{ paddingLeft: "5px" }}>
                  <Grid item xs={4} >
                    <TextField
                      className="price-txt"
                      id="outlined-bare"
                      defaultValue="$ 8774379"
                      margin="normal"
                      variant="outlined"
                    />
                  </Grid>&nbsp;
        <Grid item xs={4}>
                    <TextField
                      className="price-txt"
                      id="outlined-bare"
                      defaultValue="$ 76734868"
                      margin="normal"
                      variant="outlined"
                    />
                  </Grid>&nbsp;
        <Grid item xs={3}>
                    <Button variant="contained" className="price-btn">Go</Button>
                  </Grid>
                </Grid>
              </div>
              {filter.map(row => (
                <>
                {/* button */}  <ListItem  key={row} className=""
                    onClick={() => this.selectItem(row)}>
                    <ListItemText
                    >
                      <Typography className="fil-list-items"
                        variant=""
                      >{row}
                      </Typography>
                    </ListItemText>
                    {this.filter ? <ExpandMore className="fil-drawer-arrow" /> :
                      <ExpandLess className="fil-drawer-arrow" />}
                  </ListItem>
                  <div style={{ maxHeight: '200px', overflow: 'auto' }}>
                    {selected === row &&
                      filter1[row] !== undefined && filter1[row].map(row => (
                        <ListItem  key={row}  >   {/* button */}
                          <Checkbox
                            className="fil-submenu-icons"
                            value="checkedB"
                            color="primary"
                          />
                          <ListItemText>
                            <Typography className="" variant=""
                              className="fil-submenu-list">{row}
                            </Typography>
                          </ListItemText>
                        </ListItem>
                      ))
                    }
                  </div>
                </>
              ))}
            </List>
        </Drawer>
        </div>


        );


