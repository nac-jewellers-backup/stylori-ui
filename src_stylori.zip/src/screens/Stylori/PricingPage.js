import React from 'react';
import ProductDetail from 'containers/productDetail';

export default class Stylori extends React.Component {
  render() {

    return (
      <div>

       <ProductDetail />


      </div>
    )
  }
}
